create function st_alphashape(g1 geometry, alpha double precision DEFAULT 1.0, allow_holes boolean DEFAULT false) returns geometry
    immutable
    language sql
as
$$
	SELECT _postgis_deprecate(
		'ST_AlphaShape', 'CG_AlphaShape', '3.5.0');
	SELECT CG_AlphaShape($1, $2, $3);
$$;

alter function st_alphashape(geometry, double precision, boolean) owner to davids;

