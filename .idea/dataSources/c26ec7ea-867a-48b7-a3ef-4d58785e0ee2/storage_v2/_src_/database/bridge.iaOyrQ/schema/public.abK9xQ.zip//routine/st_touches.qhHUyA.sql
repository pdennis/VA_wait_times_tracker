create function st_touches(rast1 raster, rast2 raster) returns boolean
    immutable
    parallel safe
    cost 1000
    language sql
as
$$ SELECT public.st_touches($1, NULL::integer, $2, NULL::integer) $$;

alter function st_touches(raster, raster) owner to davids;

