create function postgis_scripts_build_date() returns text
    immutable
    language sql
as
$$SELECT ''::text AS version$$;

alter function postgis_scripts_build_date() owner to davids;

