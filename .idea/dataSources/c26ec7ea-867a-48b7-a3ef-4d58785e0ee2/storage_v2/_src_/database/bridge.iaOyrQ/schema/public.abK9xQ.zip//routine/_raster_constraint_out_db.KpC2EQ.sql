create function _raster_constraint_out_db(rast raster) returns boolean[]
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT pg_catalog.array_agg(isoutdb)::boolean[] FROM public.ST_BandMetaData($1, ARRAY[]::int[]); $$;

alter function _raster_constraint_out_db(raster) owner to davids;

