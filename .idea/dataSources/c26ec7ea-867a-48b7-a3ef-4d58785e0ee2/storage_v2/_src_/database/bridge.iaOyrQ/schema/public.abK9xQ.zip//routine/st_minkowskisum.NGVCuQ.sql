create function st_minkowskisum(geometry, geometry) returns geometry
    immutable
    language sql
as
$$
	SELECT _postgis_deprecate(
		'ST_MinkowskiSum', 'CG_MinkowsikSum', '3.5.0');
	SELECT CG_MinkowskiSum($1, $2);
$$;

alter function st_minkowskisum(geometry, geometry) owner to davids;

