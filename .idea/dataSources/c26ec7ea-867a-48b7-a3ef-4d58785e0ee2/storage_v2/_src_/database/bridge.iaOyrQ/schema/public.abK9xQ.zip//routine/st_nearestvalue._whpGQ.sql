create function st_nearestvalue(rast raster, band integer, columnx integer, rowy integer, exclude_nodata_value boolean DEFAULT true) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT public.st_nearestvalue($1, $2, public.st_setsrid(public.st_makepoint(public.st_rastertoworldcoordx($1, $3, $4), public.st_rastertoworldcoordy($1, $3, $4)), public.st_srid($1)), $5) $$;

alter function st_nearestvalue(raster, integer, integer, integer, boolean) owner to davids;

