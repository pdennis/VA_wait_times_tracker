create function st_straightskeleton(geometry) returns geometry
    immutable
    language sql
as
$$
	SELECT _postgis_deprecate(
		'ST_StraightSkeleton', 'CG_StraightSkeleton', '3.1.0');
	SELECT CG_StraightSkeleton($1, false);
$$;

alter function st_straightskeleton(geometry) owner to davids;

