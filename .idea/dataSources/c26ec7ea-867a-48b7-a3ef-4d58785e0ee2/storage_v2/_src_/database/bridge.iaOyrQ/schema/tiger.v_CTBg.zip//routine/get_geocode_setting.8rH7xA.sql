create function get_geocode_setting(setting_name text) returns text
    stable
    language sql
as
$$
SELECT COALESCE(gc.setting,gd.setting) As setting FROM geocode_settings_default AS gd LEFT JOIN geocode_settings AS gc ON gd.name = gc.name  WHERE gd.name = $1;
$$;

alter function get_geocode_setting(text) owner to davids;

