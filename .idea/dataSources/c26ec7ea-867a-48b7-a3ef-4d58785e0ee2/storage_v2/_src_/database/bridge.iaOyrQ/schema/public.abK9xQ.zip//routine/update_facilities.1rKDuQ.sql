create procedure update_facilities()
    language plpgsql
as
$$
DECLARE
    r_count integer;
BEGIN
    INSERT INTO facility (station_id,
                          facility,
                          address,
                          website,
                          mailing_address,
                          state,
                          phones)
    select station_id,
           facility,
           coalesce(min(address), '')                              as address,
           min(website)                                            as website,
           string_agg(distinct mailing_address, ', ')              as mailing_address,
           min(state)                                              as state,
           array_to_string(array_merge_agg(distinct phones), ', ') as phones
    from facility_staging
    group by station_id, facility, normalized_address
    on conflict (station_id, facility, address)
        do update
        set website         = EXCLUDED.website,
            phones          = EXCLUDED.phones,
            mailing_address = EXCLUDED.mailing_address,
            updated         = now();
    GET DIAGNOSTICS r_count := ROW_COUNT;
    raise notice '% new rows inserted', r_count;

END;
$$;

alter procedure update_facilities() owner to davids;

