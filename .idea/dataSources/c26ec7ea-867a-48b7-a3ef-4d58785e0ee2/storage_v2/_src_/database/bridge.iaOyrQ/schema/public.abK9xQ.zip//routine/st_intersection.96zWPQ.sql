create function st_intersection(rast raster, geomin geometry) returns SETOF geomval
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT public.ST_Intersection($2, $1, 1) $$;

alter function st_intersection(raster, geometry) owner to davids;

