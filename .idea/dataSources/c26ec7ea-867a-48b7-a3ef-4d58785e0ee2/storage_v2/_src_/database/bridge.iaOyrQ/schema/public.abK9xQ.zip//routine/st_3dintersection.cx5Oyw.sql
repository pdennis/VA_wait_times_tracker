create function st_3dintersection(geom1 geometry, geom2 geometry) returns geometry
    immutable
    language sql
as
$$
	SELECT _postgis_deprecate(
		'ST_3DIntersection', 'CG_3DIntersection', '3.5.0');
	SELECT CG_3DIntersection($1, $2);
$$;

alter function st_3dintersection(geometry, geometry) owner to davids;

