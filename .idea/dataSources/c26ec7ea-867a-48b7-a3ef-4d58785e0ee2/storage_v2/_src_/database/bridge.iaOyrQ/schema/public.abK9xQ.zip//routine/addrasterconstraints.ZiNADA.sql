create function addrasterconstraints(rasttable name, rastcolumn name, VARIADIC constraints text[]) returns boolean
    strict
    language sql
as
$$ SELECT public.AddRasterConstraints('', $1, $2, VARIADIC $3) $$;

alter function addrasterconstraints(name, name, text[]) owner to davids;

