create function st_pixelascentroid(rast raster, x integer, y integer) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT geom FROM public._ST_pixelascentroids($1, NULL, $2, $3) $$;

alter function st_pixelascentroid(raster, integer, integer) owner to davids;

