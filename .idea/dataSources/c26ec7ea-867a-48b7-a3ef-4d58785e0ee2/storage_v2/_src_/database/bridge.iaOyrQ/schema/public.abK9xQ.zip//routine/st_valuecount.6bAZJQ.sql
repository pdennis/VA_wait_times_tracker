create function st_valuecount(rastertable text, rastercolumn text, nband integer, searchvalue double precision, roundto double precision DEFAULT 0) returns integer
    stable
    strict
    language sql
as
$$ SELECT ( public._ST_valuecount($1, $2, $3, TRUE, ARRAY[$4]::double precision[], $5)).count $$;

alter function st_valuecount(text, text, integer, double precision, double precision) owner to davids;

