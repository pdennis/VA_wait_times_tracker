create function st_pixelofvalue(rast raster, search double precision, exclude_nodata_value boolean DEFAULT true)
    returns TABLE(x integer, y integer)
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT x, y FROM public.ST_PixelOfValue($1, 1, ARRAY[$2], $3) $$;

alter function st_pixelofvalue(raster, double precision, boolean) owner to davids;

