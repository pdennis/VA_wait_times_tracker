create function st_pixelascentroids(rast raster, band integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true)
    returns TABLE(geom geometry, val double precision, x integer, y integer)
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT geom, val, x, y FROM public._ST_pixelascentroids($1, $2, NULL, NULL, $3) $$;

alter function st_pixelascentroids(raster, integer, boolean) owner to davids;

