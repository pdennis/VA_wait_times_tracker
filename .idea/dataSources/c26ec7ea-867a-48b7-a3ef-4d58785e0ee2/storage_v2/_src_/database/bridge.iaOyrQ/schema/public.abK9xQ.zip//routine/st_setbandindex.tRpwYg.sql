create function st_setbandindex(rast raster, band integer, outdbindex integer, force boolean DEFAULT false) returns raster
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT public.ST_SetBandPath($1, $2, NULL, $3, $4) $$;

alter function st_setbandindex(raster, integer, integer, boolean) owner to davids;

