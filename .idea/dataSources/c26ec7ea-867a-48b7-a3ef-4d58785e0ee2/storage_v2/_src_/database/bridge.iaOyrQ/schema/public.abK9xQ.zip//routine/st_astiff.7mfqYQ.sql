create function st_astiff(rast raster, nbands integer[], compression text, srid integer DEFAULT NULL::integer) returns bytea
    immutable
    parallel safe
    language sql
as
$$ SELECT public.st_astiff(public.st_band($1, $2), $3, $4) $$;

alter function st_astiff(raster, integer[], text, integer) owner to davids;

