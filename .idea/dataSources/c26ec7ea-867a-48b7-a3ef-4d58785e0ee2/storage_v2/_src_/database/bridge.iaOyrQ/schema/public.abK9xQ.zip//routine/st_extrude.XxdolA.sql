create function st_extrude(geometry, double precision, double precision, double precision) returns geometry
    immutable
    language sql
as
$$
	SELECT _postgis_deprecate(
		'ST_Extrude', 'CG_Extrude', '3.5.0');
	SELECT CG_Extrude($1, $2, $3, $4);
$$;

alter function st_extrude(geometry, double precision, double precision, double precision) owner to davids;

