create function st_aspng(rast raster, nband integer, options text[] DEFAULT NULL::text[]) returns bytea
    immutable
    parallel safe
    language sql
as
$$ SELECT public.st_aspng(public.st_band($1, $2), $3) $$;

alter function st_aspng(raster, integer, text[]) owner to davids;

