create function st_orientation(geometry) returns integer
    immutable
    language sql
as
$$
	SELECT _postgis_deprecate(
		'ST_Orientation', 'CG_Orientation', '3.5.0');
	SELECT CG_Orientation($1);
$$;

alter function st_orientation(geometry) owner to davids;

