create function st_dwithin(rast1 raster, rast2 raster, distance double precision) returns boolean
    immutable
    parallel safe
    cost 1000
    language sql
as
$$ SELECT public.st_dwithin($1, NULL::integer, $2, NULL::integer, $3) $$;

alter function st_dwithin(raster, raster, double precision) owner to davids;

