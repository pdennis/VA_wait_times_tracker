create function updaterastersrid(table_name name, column_name name, new_srid integer) returns boolean
    strict
    language sql
as
$$ SELECT  public._UpdateRasterSRID('', $1, $2, $3) $$;

alter function updaterastersrid(name, name, integer) owner to davids;

