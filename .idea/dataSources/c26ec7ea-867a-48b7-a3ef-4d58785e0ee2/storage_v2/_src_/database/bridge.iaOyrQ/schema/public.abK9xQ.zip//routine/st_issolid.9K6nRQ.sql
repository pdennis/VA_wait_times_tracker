create function st_issolid(geometry) returns boolean
    immutable
    language sql
as
$$
	SELECT _postgis_deprecate(
		'ST_IsSolid', 'CG_IsSolid', '3.5.0');
	SELECT CG_IsSolid($1);
$$;

alter function st_issolid(geometry) owner to davids;

