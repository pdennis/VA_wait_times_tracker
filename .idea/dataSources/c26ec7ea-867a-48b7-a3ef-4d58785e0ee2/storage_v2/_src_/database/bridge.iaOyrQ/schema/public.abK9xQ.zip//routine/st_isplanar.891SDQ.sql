create function st_isplanar(geometry) returns boolean
    immutable
    language sql
as
$$
	SELECT _postgis_deprecate(
		'ST_IsPlanar', 'CG_IsPlanar', '3.5.0');
	SELECT CG_IsPlanar($1);
$$;

alter function st_isplanar(geometry) owner to davids;

