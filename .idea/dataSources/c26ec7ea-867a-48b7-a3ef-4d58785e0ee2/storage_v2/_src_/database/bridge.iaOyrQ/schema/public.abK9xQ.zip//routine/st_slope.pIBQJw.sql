create function st_slope(rast raster, nband integer DEFAULT 1, pixeltype text DEFAULT '32BF'::text, units text DEFAULT 'DEGREES'::text, scale double precision DEFAULT 1.0, interpolate_nodata boolean DEFAULT false) returns raster
    immutable
    parallel safe
    language sql
as
$$ SELECT public.ST_slope($1, $2, NULL::public.raster, $3, $4, $5, $6) $$;

alter function st_slope(raster, integer, text, text, double precision, boolean) owner to davids;

