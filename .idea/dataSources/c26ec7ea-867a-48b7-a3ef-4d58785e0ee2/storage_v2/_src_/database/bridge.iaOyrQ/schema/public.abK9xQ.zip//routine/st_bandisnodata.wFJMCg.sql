create function st_bandisnodata(rast raster, forcechecking boolean) returns boolean
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT public.ST_bandisnodata($1, 1, $2) $$;

alter function st_bandisnodata(raster, boolean) owner to davids;

