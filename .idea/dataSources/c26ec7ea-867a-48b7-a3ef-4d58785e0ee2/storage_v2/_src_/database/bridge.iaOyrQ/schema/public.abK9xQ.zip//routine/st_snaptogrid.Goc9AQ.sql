create function st_snaptogrid(geometry, double precision, double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT public.ST_SnapToGrid($1, 0, 0, $2, $3)$$;

alter function st_snaptogrid(geometry, double precision, double precision) owner to davids;

