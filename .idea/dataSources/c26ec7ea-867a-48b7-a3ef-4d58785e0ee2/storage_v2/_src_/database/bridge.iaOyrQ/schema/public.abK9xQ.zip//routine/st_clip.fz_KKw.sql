create function st_clip(rast raster, geom geometry, nodataval double precision, crop boolean DEFAULT true, touched boolean DEFAULT false) returns raster
    immutable
    parallel safe
    language sql
as
$$ SELECT public.ST_Clip(rast, NULL, geom, ARRAY[nodataval]::float8[], crop, touched) $$;

alter function st_clip(raster, geometry, double precision, boolean, boolean) owner to davids;

