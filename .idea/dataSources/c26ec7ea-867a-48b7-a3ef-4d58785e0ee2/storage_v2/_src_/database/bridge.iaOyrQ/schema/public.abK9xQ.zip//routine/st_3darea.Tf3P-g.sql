create function st_3darea(geometry) returns double precision
    immutable
    language sql
as
$$
	SELECT _postgis_deprecate(
		'ST_3DArea', 'CG_3DArea', '3.5.0');
	SELECT CG_3DArea($1);
$$;

alter function st_3darea(geometry) owner to davids;

