create function st_volume(geometry) returns double precision
    immutable
    language sql
as
$$
	SELECT _postgis_deprecate(
		'ST_Volume', 'CG_Volume', '3.5.0');
	SELECT CG_Volume($1);
$$;

alter function st_volume(geometry) owner to davids;

