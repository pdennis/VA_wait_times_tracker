create function st_dfullywithin(rast1 raster, rast2 raster, distance double precision) returns boolean
    immutable
    parallel safe
    cost 1000
    language sql
as
$$ SELECT public.ST_DFullyWithin($1, NULL::integer, $2, NULL::integer, $3) $$;

alter function st_dfullywithin(raster, raster, double precision) owner to davids;

