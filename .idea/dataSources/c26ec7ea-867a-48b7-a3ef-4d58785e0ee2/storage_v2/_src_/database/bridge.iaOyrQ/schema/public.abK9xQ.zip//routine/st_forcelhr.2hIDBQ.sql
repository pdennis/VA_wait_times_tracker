create function st_forcelhr(geometry) returns geometry
    immutable
    language sql
as
$$
	SELECT _postgis_deprecate(
		'ST_ForceLHR', 'CG_ForceLHR', '3.5.0');
	SELECT CG_ForceLHR($1);
$$;

alter function st_forcelhr(geometry) owner to davids;

