create function st_clip(rast raster, geom geometry, crop boolean, touched boolean DEFAULT false) returns raster
    immutable
    parallel safe
    language sql
as
$$ SELECT public.ST_Clip(rast, NULL, geom, null::float8[], crop, touched) $$;

alter function st_clip(raster, geometry, boolean, boolean) owner to davids;

