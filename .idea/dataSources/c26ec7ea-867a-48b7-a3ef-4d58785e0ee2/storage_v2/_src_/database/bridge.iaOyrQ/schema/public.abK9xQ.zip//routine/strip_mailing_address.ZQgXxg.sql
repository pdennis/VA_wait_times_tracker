create function strip_mailing_address(str text) returns text
    strict
    language plpgsql
as
$$
DECLARE
    v_token_pos int;
    v_str       text;
BEGIN
    v_token_pos = position('Mailing Address: ' in str);
    if v_token_pos > 0 then
        v_str := trim(substring(str, 1, v_token_pos - 1));
        if RIGHT(v_str, 1) = ',' then
            v_str := LEFT(v_str, LENGTH(v_str) - 1);
        end if;
    else
        v_str := str;
    end if;

    return trim(v_str);
END;
$$;

alter function strip_mailing_address(text) owner to davids;

