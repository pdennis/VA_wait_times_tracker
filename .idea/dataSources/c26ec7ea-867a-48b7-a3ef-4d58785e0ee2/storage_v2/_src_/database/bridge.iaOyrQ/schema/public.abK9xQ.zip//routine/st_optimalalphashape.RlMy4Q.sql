create function st_optimalalphashape(g1 geometry, allow_holes boolean DEFAULT false, nb_components integer DEFAULT 1) returns geometry
    immutable
    language sql
as
$$
	SELECT _postgis_deprecate(
		'ST_OptimalAlphaShape', 'CG_OptimalAlphaShape', '3.5.0');
	SELECT CG_OptimalAlphaShape($1, $2, $3);
$$;

alter function st_optimalalphashape(geometry, boolean, integer) owner to davids;

