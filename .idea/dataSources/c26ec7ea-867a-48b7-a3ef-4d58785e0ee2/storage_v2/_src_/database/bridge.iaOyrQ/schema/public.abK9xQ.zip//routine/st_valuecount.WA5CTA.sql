create function st_valuecount(rast raster, searchvalue double precision, roundto double precision DEFAULT 0) returns integer
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT ( public._ST_valuecount($1, 1, TRUE, ARRAY[$2]::double precision[], $3)).count $$;

alter function st_valuecount(raster, double precision, double precision) owner to davids;

