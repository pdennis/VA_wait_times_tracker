create function st_clip(rast raster, nband integer, geom geometry, nodataval double precision, crop boolean DEFAULT true, touched boolean DEFAULT false) returns raster
    immutable
    parallel safe
    language sql
as
$$ SELECT public.ST_Clip(rast, ARRAY[nband]::integer[], geom, ARRAY[nodataval]::float8[], crop, touched) $$;

alter function st_clip(raster, integer, geometry, double precision, boolean, boolean) owner to davids;

