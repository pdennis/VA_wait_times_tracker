create function extract_mailing_address(str text) returns text
    strict
    language plpgsql
as
$$
DECLARE
    v_token_pos int;
    v_str       text;
BEGIN
    v_token_pos = position('Mailing Address: ' in str);
    if v_token_pos > 0 then
        v_str := trim(substring(str, v_token_pos + length('Mailing Address: ')));
    else
        v_str := NULL;
    end if;

    return v_str;
END;
$$;

alter function extract_mailing_address(text) owner to davids;

