create function st_neighborhood(rast raster, pt geometry, distancex integer, distancey integer, exclude_nodata_value boolean DEFAULT true) returns double precision[]
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT public.st_neighborhood($1, 1, $2, $3, $4, $5) $$;

alter function st_neighborhood(raster, geometry, integer, integer, boolean) owner to davids;

