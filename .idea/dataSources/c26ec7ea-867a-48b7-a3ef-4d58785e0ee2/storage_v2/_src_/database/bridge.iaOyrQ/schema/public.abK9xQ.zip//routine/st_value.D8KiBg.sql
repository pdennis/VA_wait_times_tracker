create function st_value(rast raster, x integer, y integer, exclude_nodata_value boolean DEFAULT true) returns double precision
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$ SELECT public.st_value($1, 1::integer, $2, $3, $4) $$;

alter function st_value(raster, integer, integer, boolean) owner to davids;

