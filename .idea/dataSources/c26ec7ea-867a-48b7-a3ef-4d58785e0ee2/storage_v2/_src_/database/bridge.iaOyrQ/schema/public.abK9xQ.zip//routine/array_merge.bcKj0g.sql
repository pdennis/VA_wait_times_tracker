create function array_merge(arr1 anyarray, arr2 anyarray) returns anyarray
    immutable
    language sql
as
$$
select array_agg(distinct elem order by elem)
from (select unnest(arr1) elem
      union
      select unnest(arr2)) s
$$;

alter function array_merge(anyarray, anyarray) owner to davids;

