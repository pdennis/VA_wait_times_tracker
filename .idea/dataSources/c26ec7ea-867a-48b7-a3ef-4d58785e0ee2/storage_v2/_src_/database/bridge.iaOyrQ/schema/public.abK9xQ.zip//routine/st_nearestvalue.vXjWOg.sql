create function st_nearestvalue(rast raster, pt geometry, exclude_nodata_value boolean DEFAULT true) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT public.st_nearestvalue($1, 1, $2, $3) $$;

alter function st_nearestvalue(raster, geometry, boolean) owner to davids;

