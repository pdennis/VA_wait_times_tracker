create function st_worldtorastercoord(rast raster, longitude double precision, latitude double precision, OUT columnx integer, OUT rowy integer) returns record
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT columnx, rowy FROM public._ST_worldtorastercoord($1, $2, $3) $$;

alter function st_worldtorastercoord(raster, double precision, double precision, out integer, out integer) owner to davids;

