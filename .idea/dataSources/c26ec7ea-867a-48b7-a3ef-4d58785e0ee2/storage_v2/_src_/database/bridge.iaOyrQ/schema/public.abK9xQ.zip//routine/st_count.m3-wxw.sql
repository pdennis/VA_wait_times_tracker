create function st_count(rast raster, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true) returns bigint
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT public._ST_count($1, $2, $3, 1) $$;

alter function st_count(raster, integer, boolean) owner to davids;

