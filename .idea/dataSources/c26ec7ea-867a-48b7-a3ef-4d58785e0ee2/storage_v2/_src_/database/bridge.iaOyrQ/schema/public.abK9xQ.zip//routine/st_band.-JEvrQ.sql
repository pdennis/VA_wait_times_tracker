create function st_band(rast raster, nbands text, delimiter character DEFAULT ','::bpchar) returns raster
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT  public.ST_band($1, pg_catalog.regexp_split_to_array(pg_catalog.regexp_replace($2, '[[:space:]]', '', 'g'), E'\\' || pg_catalog.array_to_string(pg_catalog.regexp_split_to_array($3, ''), E'\\'))::int[]) $$;

alter function st_band(raster, text, char) owner to davids;

