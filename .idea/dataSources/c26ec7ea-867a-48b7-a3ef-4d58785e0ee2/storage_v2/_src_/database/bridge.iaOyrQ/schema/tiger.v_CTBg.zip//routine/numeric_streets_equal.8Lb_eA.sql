create function numeric_streets_equal(input_street character varying, output_street character varying) returns boolean
    immutable
    parallel safe
    cost 5
    language sql
as
$$
    SELECT COALESCE(length($1) < 10 AND length($2) < 10
            AND $1 ~ E'^[0-9\/\s]+' AND $2 ~ E'^[0-9\/\s]+'
            AND  trim(substring($1, E'^[0-9\/\s]+')) = trim(substring($2, E'^[0-9\/\s]+')), false);
$$;

alter function numeric_streets_equal(varchar, varchar) owner to davids;

