create function _st_samealignment_transfn(agg agg_samealignment, rast raster) returns agg_samealignment
    immutable
    parallel safe
    language plpgsql
as
$$
	DECLARE
		m record;
		aligned boolean;
	BEGIN
		IF agg IS NULL THEN
			agg.refraster := NULL;
			agg.aligned := NULL;
		END IF;

		IF rast IS NULL THEN
			agg.aligned := NULL;
		ELSE
			IF agg.refraster IS NULL THEN
				m := public.ST_Metadata(rast);
				agg.refraster := public.ST_MakeEmptyRaster(1, 1, m.upperleftx, m.upperlefty, m.scalex, m.scaley, m.skewx, m.skewy, m.srid);
				agg.aligned := TRUE;
			ELSIF agg.aligned IS TRUE THEN
				agg.aligned := public.ST_SameAlignment(agg.refraster, rast);
			END IF;
		END IF;
		RETURN agg;
	END;
	$$;

alter function _st_samealignment_transfn(agg_samealignment, raster) owner to davids;

