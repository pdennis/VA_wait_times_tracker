create function st_asjpeg(rast raster, nbands integer[], options text[] DEFAULT NULL::text[]) returns bytea
    immutable
    parallel safe
    language sql
as
$$ SELECT public.st_asjpeg(public.st_band($1, $2), $3) $$;

alter function st_asjpeg(raster, integer[], text[]) owner to davids;

