create function st_bandmetadata(rast raster, band integer DEFAULT 1)
    returns TABLE(pixeltype text, nodatavalue double precision, isoutdb boolean, path text, outdbbandnum integer, filesize bigint, filetimestamp bigint)
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT pixeltype, nodatavalue, isoutdb, path, outdbbandnum, filesize, filetimestamp FROM public.ST_BandMetaData($1, ARRAY[$2]::int[]) LIMIT 1 $$;

alter function st_bandmetadata(raster, integer) owner to davids;

