create function st_approximatemedialaxis(geometry) returns geometry
    immutable
    language sql
as
$$
	SELECT _postgis_deprecate(
		'ST_ApproximateMedialAxis', 'CG_ApproximateMedialAxis', '3.5.0');
	SELECT CG_ApproximateMedialAxis($1);
$$;

alter function st_approximatemedialaxis(geometry) owner to davids;

