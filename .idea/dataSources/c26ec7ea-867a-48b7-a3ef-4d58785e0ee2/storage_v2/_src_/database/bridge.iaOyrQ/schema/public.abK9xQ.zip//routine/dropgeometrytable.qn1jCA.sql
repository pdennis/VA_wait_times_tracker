create function dropgeometrytable(schema_name character varying, table_name character varying) returns text
    strict
    language sql
as
$$ SELECT public.DropGeometryTable('',$1,$2) $$;

alter function dropgeometrytable(varchar, varchar) owner to davids;

