create procedure update_stations()
    language plpgsql
as
$$
DECLARE
    r_count integer;
BEGIN
    INSERT INTO station (station_id)
    select distinct station_id
    from facility
    order by station_id
    on conflict DO NOTHING;
    GET DIAGNOSTICS r_count := ROW_COUNT;
    raise notice '% new rows inserted', r_count;
END;
$$;

alter procedure update_stations() owner to davids;

