create function generate_report_hash() returns trigger
    language plpgsql
as
$$
BEGIN
    IF tg_op = 'INSERT' OR tg_op = 'UPDATE' THEN
        NEW.hash = digest(NEW.report, 'sha512');
        RETURN NEW;
    END IF;
END;
$$;

alter function generate_report_hash() owner to davids;

