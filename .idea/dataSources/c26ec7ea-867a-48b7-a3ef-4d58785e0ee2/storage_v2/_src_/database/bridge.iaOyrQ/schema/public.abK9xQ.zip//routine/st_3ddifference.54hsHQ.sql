create function st_3ddifference(geom1 geometry, geom2 geometry) returns geometry
    immutable
    language sql
as
$$
	SELECT _postgis_deprecate(
		'ST_3DDifference', 'CG_3DDifference', '3.5.0');
	SELECT CG_3DDifference($1, $2);
$$;

alter function st_3ddifference(geometry, geometry) owner to davids;

