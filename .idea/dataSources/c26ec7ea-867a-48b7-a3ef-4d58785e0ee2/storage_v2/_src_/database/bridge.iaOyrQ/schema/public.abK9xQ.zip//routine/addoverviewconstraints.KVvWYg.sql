create function addoverviewconstraints(ovtable name, ovcolumn name, reftable name, refcolumn name, ovfactor integer) returns boolean
    strict
    language sql
as
$$ SELECT  public.AddOverviewConstraints('', $1, $2, '', $3, $4, $5) $$;

alter function addoverviewconstraints(name, name, name, name, integer) owner to davids;

