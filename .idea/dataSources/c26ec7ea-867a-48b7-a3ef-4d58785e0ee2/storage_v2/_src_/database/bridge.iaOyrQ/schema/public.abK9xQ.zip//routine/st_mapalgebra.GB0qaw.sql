create function st_mapalgebra(rast raster, nband integer, callbackfunc regprocedure, mask double precision[], weighted boolean, pixeltype text DEFAULT NULL::text, extenttype text DEFAULT 'INTERSECTION'::text, customextent raster DEFAULT NULL::raster, VARIADIC userargs text[] DEFAULT NULL::text[]) returns raster
    immutable
    parallel safe
    language sql
as
$$
	select public._ST_mapalgebra(ARRAY[ROW($1,$2)]::public.rastbandarg[],$3,$6,NULL::integer,NULL::integer,$7,$8,$4,$5,VARIADIC $9)
	$$;

alter function st_mapalgebra(raster, integer, regprocedure, double precision[], boolean, text, text, raster, text[]) owner to davids;

