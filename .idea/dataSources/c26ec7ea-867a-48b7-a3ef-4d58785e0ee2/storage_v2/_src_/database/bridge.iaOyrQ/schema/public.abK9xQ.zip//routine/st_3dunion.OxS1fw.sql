create function st_3dunion(geom1 geometry, geom2 geometry) returns geometry
    immutable
    language sql
as
$$
	SELECT _postgis_deprecate(
		'ST_3DUnion', 'CG_3DUnion', '3.5.0');
	SELECT CG_3DUnion($1, $2);
$$;

alter function st_3dunion(geometry, geometry) owner to davids;

