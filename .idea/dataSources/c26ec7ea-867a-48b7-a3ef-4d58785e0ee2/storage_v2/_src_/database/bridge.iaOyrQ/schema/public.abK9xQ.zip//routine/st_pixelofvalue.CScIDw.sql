create function st_pixelofvalue(rast raster, nband integer, search double precision, exclude_nodata_value boolean DEFAULT true)
    returns TABLE(x integer, y integer)
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT x, y FROM public.ST_PixelofValue($1, $2, ARRAY[$3], $4) $$;

alter function st_pixelofvalue(raster, integer, double precision, boolean) owner to davids;

