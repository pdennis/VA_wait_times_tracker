create function st_value(rast raster, pt geometry, exclude_nodata_value boolean DEFAULT true) returns double precision
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$ SELECT public.ST_value($1, 1::integer, $2, $3, 'nearest'::text) $$;

alter function st_value(raster, geometry, boolean) owner to davids;

