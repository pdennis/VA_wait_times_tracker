create function st_clip(rast raster, nband integer[], geom geometry, nodataval double precision[], crop boolean DEFAULT true, touched boolean DEFAULT false) returns raster
    immutable
    parallel safe
    language plpgsql
as
$$
	BEGIN
		-- short-cut if geometry's extent fully contains raster's extent
		IF (nodataval IS NULL OR array_length(nodataval, 1) < 1) AND public.ST_Contains(geom, public.ST_Envelope(rast)) THEN
			RETURN rast;
		END IF;

		RETURN public._ST_Clip(rast, nband, geom, nodataval, crop, touched);
	END;
	$$;

alter function st_clip(raster, integer[], geometry, double precision[], boolean, boolean) owner to davids;

