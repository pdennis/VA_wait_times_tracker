create function install_missing_indexes() returns boolean
    language plpgsql
as
$$
DECLARE var_sql text = missing_indexes_generate_script();
BEGIN
	EXECUTE(var_sql);
	RETURN true;
END
$$;

alter function install_missing_indexes() owner to davids;

