create function st_asbinary(raster, outasin boolean DEFAULT false) returns bytea
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT public.ST_AsWKB($1, $2) $$;

alter function st_asbinary(raster, boolean) owner to davids;

