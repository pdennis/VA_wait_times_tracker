create function st_transform(geom geometry, from_proj text, to_proj text) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language sql
as
$$SELECT public.postgis_transform_geometry($1, $2, $3, 0)$$;

alter function st_transform(geometry, text, text) owner to davids;

